#include <stdio.h>

int containBit1(int x){ //part A
    return !!x;
}

int containBit0(int x){ // part B
    return !!~x;
}

int leastSigByteContainBit1(int x){ // part C
    return !!(x & 0xFF);
}

int mostSigByteContainBit0(int x){ // part D
    // shift by w-8 (refer from textbook p.129)
    int shift_val = (sizeof(int)-1) << 3;
    return !!(~x & (0xFF << shift_val));
}

int main(){
    int foo = 0xff788980; 
    printf("The value in hexadecimal is %x\n", foo);

    printf("Test A: %d\n", containBit1(foo));
    printf("Test B: %d\n", containBit0(foo));
    printf("Test C: %d\n", leastSigByteContainBit1(foo));
    printf("Test D: %d\n", mostSigByteContainBit0(foo));
}
