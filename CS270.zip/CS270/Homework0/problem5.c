#include <stdio.h>

int main(){
    int foo = 16383;
    int bar = 1000000;

    int max_add_foo = __INT_MAX__ - foo;
    int max_add_bar = __INT_MAX__ - bar;

    printf("Largest int value is %d\n", __INT_MAX__);
    printf("Largest value of an int that can be added to foo is %d\n", max_add_foo);
    printf("Largest value of an int that can be added to foo is %d\n", max_add_bar);

    if (max_add_foo + foo == __INT_MAX__){
        printf("Success foo overflow check!\n");
    }
    if (max_add_bar + bar == __INT_MAX__){
        printf("Success bar overflow check\n");
    }
}