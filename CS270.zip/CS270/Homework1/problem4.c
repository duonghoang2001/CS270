#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main() {
    int x = INT_MIN;
    int y = INT_MAX;
    unsigned ux = (unsigned) x;
    unsigned uy = (unsigned) y;
    printf("x = %d and y = %d\n", x, y);
    printf("ux = %u and uy = %u\n", ux, uy);
    if ((x<y) == ((-x)>(-y))) {
        int neg_x = -x;
        printf("%d\n", neg_x);
        printf("A is true\n");
    }
    if (~x+~y+1 == ~(x+y)) {
        printf("C is true\n");
    }
    if (((x >> 2) << 2) <= x) {
        printf("E is true\n");
    }
}