#include <stdio.h>

long decode2(long x, long y, long z) {
    return (((y-z) << 63) >> 63) ^ ((y-z) * x);
}

long loop (long x, long n) {
    long result = 0;
    long mask;
    for (mask = 1; mask != 0; mask = mask << n) {
        result |= x & mask;
    }
    return result;
}

