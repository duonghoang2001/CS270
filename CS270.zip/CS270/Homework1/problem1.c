#include <stdio.h>

typedef unsigned packet_t;

int xbyte(packet_t word, int bytenum) {
    // extract designated byte by right shift to LSB
    word = word >> (bytenum << 3); 
    // left shift designated byte to MSB, 
    // then right shift to LSB to extend its sign
    int shift_val = (sizeof(packet_t)-1) << 3;
    return (int) (word << shift_val) >> shift_val;
}

int main() {
    packet_t word;
    int bytenum;
    printf("Enter word: ");
    scanf("%u", &word);
    printf("Enter bytenum: ");
    scanf("%d", &bytenum);
    printf("Word: %x\n", word);
    printf("Extract: %x\n", xbyte(word, bytenum));
    return 0;
}