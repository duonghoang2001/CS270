#include <stdio.h>

int expressionA(int k) { // 1^(w-k) 0^k
    return -1 << k;
}

int expressionB(int k, int j) { // 0^(w-k-j) 1^k 0^j
    return ~(-1 << k) << j;
}

int main() {
    printf("%x\n", expressionA(5));
    printf("%x\n", expressionB(6,9));
    return 0;
}