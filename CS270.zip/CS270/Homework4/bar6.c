/* bar6.c */
#include <stdio.h>

int main;

void p2() {
    printf("0x%x\n", main);
}