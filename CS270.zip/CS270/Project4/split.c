#include <stdio.h>
#include<stdlib.h>
#include <string.h>
#include <ctype.h>

#define BUFFER_SIZE 256

size_t split(char *buffer, char *tokens[])
{
    char *p, *start_of_word;
    int c;
    enum states { DULL, IN_WORD, IN_STRING } state = DULL;
    size_t numTokens = 0;

    for (p = buffer; numTokens < BUFFER_SIZE && *p != '\0'; p++) {
        c = (unsigned char) *p;
        switch (state) {
        case DULL:
            if (isspace(c)) {
                continue;
            }

            if (c == '"') {
                state = IN_STRING;
                start_of_word = p + 1; 
                continue;
            }
            state = IN_WORD;
            start_of_word = p;
            continue;

        case IN_STRING:
            if (c == '"') {
                *p = 0;
                tokens[numTokens++] = start_of_word;
                state = DULL;
            }
            continue;

        case IN_WORD:
            if (isspace(c)) {
                *p = 0;
                tokens[numTokens++] = start_of_word;
                state = DULL;
            }
            continue;
        }
    }

    if (state != DULL && numTokens < BUFFER_SIZE)
        tokens[numTokens++] = start_of_word;

    return numTokens;
}
void test_split(const char *s, char** list)
{
    char buf[BUFFER_SIZE];
    size_t i, argc;
    char *argv[BUFFER_SIZE];

    strcpy(buf, s);
    argc = split(buf, argv);
    printf("input: '%s'\n", s);
    for (i = 0; i < argc; i++) {
        printf("[%u] '%s'\n", i, argv[i]);
        *(list+i) = argv[i];
    }
}
int main(int ac, char *av[])
{
    char inputLine[BUFFER_SIZE];
    char** list = calloc(BUFFER_SIZE, sizeof(char*));
    if (fgets(inputLine, BUFFER_SIZE, stdin) == 0);
    if (inputLine[strlen(inputLine) - 1] == '\n')
        inputLine[strlen(inputLine) - 1] = '\0';
    test_split(inputLine, list);
    for (int i = 0; i < 4; i++) {
        printf("%s\n", list[i]);
    }
    return 0;
}