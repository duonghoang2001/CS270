#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <dirent.h>
#include <errno.h>
#include <wait.h>
#include <ctype.h>

#define BUFFER_SIZE 256

typedef void (*sighandler_t)(int);

typedef struct VariableStruct {
    char* name;
    char* value; 
} Variable;

typedef struct VariableListStruct {
    Variable** list;
    int numVariables;
} VarList;

Variable *makeVar(char* name, char* value) {
    Variable *newVar = (Variable *) malloc (sizeof(Variable));
    newVar->name = (char*) malloc (strlen(name) + 1);
    newVar->value = (char*) malloc (strlen(value) + 1);
    strcpy(newVar->name, name);
    strcpy(newVar->value, value);
    return newVar;
}
VarList *makeList() {
    VarList *theList = (VarList *) malloc (sizeof(VarList));
    theList->numVariables = 0;
    theList->list = (Variable **) calloc (BUFFER_SIZE, sizeof(Variable *));
    for (int i = 0; i < BUFFER_SIZE; i++) theList->list[i] = NULL;
    return theList;
} // makeList

void reportError(char *error) {
    printf("%s error\n", error);
} // reportError

void sigint_handler() {
    printf(" Ignore ^C. Press enter for next prompt!");
} // signal handler for SIGINT

sighandler_t Signal(int signum, sighandler_t handler) {
    struct sigaction action, old_action;
    action.sa_handler = handler;
    sigemptyset(&action.sa_mask);
    action.sa_flags = SA_RESTART;
    
    if (sigaction(signum, &action, &old_action) < 0) reportError("Signal");
    
    return (old_action.sa_handler);
} // signal installing handler

void addVariables(VarList *theList, char* name, char* value) {
    Variable *newVar = makeVar(name, value);
    int index = theList->numVariables;
    theList->list[index] = newVar;
    theList->numVariables++;
} // addVariables

size_t splitTokens(char *buffer, char *tokens[]) {
    char *p = NULL;
    char *start_of_word = NULL;
    int c;
    enum states { DULL, IN_WORD, IN_STRING } state = DULL;
    size_t numTokens = 0;

    for (p = buffer; numTokens < BUFFER_SIZE && *p != '\0'; p++) {
        c = (unsigned char) *p;
        switch (state) {
        case DULL:
            if (isspace(c)) continue;
            if (c == '"') {
                state = IN_STRING;
                start_of_word = p + 1; 
                continue;
            }
            state = IN_WORD;
            start_of_word = p;
            continue;

        case IN_STRING:
            if (c == '"') {
                *p = 0;
                tokens[numTokens++] = start_of_word;
                state = DULL;
            }
            continue;

        case IN_WORD:
            if (isspace(c)) {
                *p = 0;
                tokens[numTokens++] = start_of_word;
                state = DULL;
            }
            continue;
        }
    }

    if (state != DULL && numTokens < BUFFER_SIZE)
        tokens[numTokens++] = start_of_word;

    return numTokens;
} // splitTokens

size_t getTokens(const char *s, char** list) {
    char buf[BUFFER_SIZE];
    size_t i, numTokens;
    char *tokens[BUFFER_SIZE];

    strcpy(buf, s);
    numTokens = splitTokens(buf, tokens);
    for (i = 0; i < numTokens; i++) *(list+i) = tokens[i];

    return numTokens;
} // getTokens

void substituteVar(VarList* theList, char** parse, int numTokens) {
    for (int i = 0; i < numTokens; i++) {
        if (parse[i][0] == '$') {
            char variable[BUFFER_SIZE] = "";
            strncpy(variable, parse[i]+1, strlen(parse[i]) - 1);
            for (int j = 0; j < theList->numVariables; j++) {
                if (!strcmp(variable, theList->list[j]->name)) { // found variable
                    strcpy(parse[i], theList->list[j]->value);
                }
            }
            printf("%s\n", parse[i]);
        }
    }
}

void cd(VarList* theList, char* newDir) {
    if (!chdir(newDir)) { // change directory successfully
        strcpy(theList->list[0]->value, newDir); // update varList
        printf("Current directory: %s\n", newDir);
    } 
    else reportError("cd");
} // cd Command

void lv(VarList* theList) {
    for (int i = 0; i < theList->numVariables; i++) {
        printf("%s = %s\n", theList->list[i]->name, theList->list[i]->value);
    }
} // lv Command

void unset(VarList* theList, char* deleteVar) {
    if (!strcmp(deleteVar, "CWD")) reportError("Built-in var unset");
    else if (!strcmp(deleteVar, "PS")) reportError("Built-in var unset");
    else if (!strcmp(deleteVar, "PATH")) reportError("Built-in var unset");
    else {
        int deleteIndex = -1;
        for (int i = 0; i < theList->numVariables; i++) {
            if (!strcmp(deleteVar, theList->list[i]->name)) {
                deleteIndex = i;
                break;
            }
        }
        if (deleteIndex > -1) { // found deleteVar in varList, remove from list
            theList->numVariables--;
            for (int j = deleteIndex; j < theList->numVariables; j++) 
                theList->list[j] = theList->list[j+1];
            theList->list[theList->numVariables + 1] = NULL; 
            printf("%s is unset successfully!\n", deleteVar);
        } else reportError("Unknown var unset");
    }
} // unset

bool validName(char* name) {
    if (!isalpha(name[0])) return false;
    for (int i = 0; i < strlen(name); i++) 
        if(!isalnum(name[i])) return false;
    return true;
}

void assignment(VarList* theList, char* name, char* value) {
    if (!validName(name)) {
        reportError("Invalid var name");
        return;
    }
    if (!strcmp(name, "CWD")) {
        reportError("Assign directory");
        return;
    }
    for (int i = 0; i < theList->numVariables; i++) { // if var exists in list
        if (!strcmp(name, theList->list[i]->name)) {
            strcpy(theList->list[i]->value, value); // update value
            printf("%s = %s is stored successfully!\n", name, value);
            return; 
        }
    }
    addVariables(theList, name, value); // if var is new var, add var to list
    printf("%s = %s is stored successfully!\n", name, value);
} // assignment command

void execute(char** parse, int numTokens, char* CWD, char* PS, char* PATH) {
    // ! cmd param* [infrom:  file0] [outto:  file1] 
    // Either infrom: or outto: or both may be omitted, and either may come first
    char* cmd = parse[1];
   
    int numParams = numTokens - 2; // excude "!" and "cmd"
    
    // detect infrom: and outto:
    char file0[BUFFER_SIZE] = "";
    char file1[BUFFER_SIZE] = "";

    if (numTokens > 6) {
        for (int i = numTokens - 4; i < numTokens; i+=2) {
            if (!strcmp(parse[i], "infrom:")) {
                strcpy(file0, parse[i+1]);
                numParams -= 2;
            } else if (!strcmp(parse[i], "outto:")) {
                strcpy(file1, parse[i+1]);
                numParams -= 2;
            }
        }
    } else if (numTokens > 4) {
        if (!strcmp(parse[numTokens-2], "infrom:")) {
            strcpy(file0, parse[numTokens-1]);
            numParams -= 2;
        } else if (!strcmp(parse[numTokens-2], "outto:")) {
            strcpy(file1, parse[numTokens-1]);
            numParams -= 2;
        }
    }
    
    // initialize path
    char path[BUFFER_SIZE] = "";
    if (cmd[0] == '/') {
        strcpy(path, "/home");
        // strcat(path, PATH);
    } else if (!strncmp(cmd, "./", 2)) strcpy(path, CWD);
    else strcpy(path, PATH);
    
    /*
    // initialize argv[]
    char *param[numParams+1];
    for (int i = 0; i < numParams; i++) strcpy(param[i], parse[i+2]);
    strcpy(param[numParams], "\0"); // NULL - terminated

    // initialize envp[]
    char *envp[4];
    envp[0] = "CWD=";
    strcat(envp[0], CWD);
    envp[1] = "PS=";
    strcat(envp[1], PS);
    envp[2] = "PATH=";
    strcat(envp[2], path);
    envp[3] = "\0"; // NULL - terminated
    */

    char *param[] = { 0 };
    char *envp[] = { 0 };

    // execute cmd
    if (fork() == 0) {
        int fd0, fd1;

        if (file0 != NULL) {
            fd0 = open(file0, O_RDONLY);
            dup2(fd0, STDIN_FILENO);
        }
        if (file1 != NULL) {
            fd1 = open(file1, O_WRONLY | O_APPEND | O_CREAT | O_TRUNC, 
                            S_IRUSR | S_IWUSR);
            dup2(fd1, STDOUT_FILENO);
        }

        if (execve(cmd, param, envp) == -1) {
            reportError("execve()");
            if (execvp(cmd, param) == -1) reportError("execvp()");
        }
        
        if (file0 != NULL) close(fd0);
        if (file1 != NULL) close(fd1);
    } else wait(NULL);
} // ! Command

void cmdHandler(VarList* theList, char** parse, int numTokens) {
    char command[BUFFER_SIZE];
    strcpy(command, parse[0]);
    
    // FIXME: detect $ and substitute tokens
    substituteVar(theList, parse, numTokens);

    if (!strcmp(command, "quit")) { exit(0); 
    } else if (!strcmp(command, "#")) { return; // ignore comment
    } else if (!strcmp(command, "cd")) {
        if (numTokens == 2) {
            char *newDir = parse[1];
            cd(theList, newDir);
        } else reportError("Wrong argc for cd");   
    } else if (!strcmp(command, "lv")) { lv(theList);
    } else if (!strcmp(command, "unset")) {
        if (numTokens == 2) {
            char* deleteVar = parse[1];
            unset(theList, deleteVar);
        } else reportError("Wrong argc for unset");
    } else if (!strcmp(command, "!")) {
        if (numTokens > 1) {
            execute(parse, numTokens, theList->list[0]->value, 
                    theList->list[1]->value, theList->list[2]->value);
        } else reportError("Wrong argc for ! cmd");
    } else if (numTokens == 3) {
        if (!strcmp(parse[1], "=")) { // variable = value cmd
            assignment(theList, parse[0], parse[2]);
        } else reportError("Unknown command");
    } else reportError("Unknown command");
} // commandHandler

int main(int argc, char* argv[]) {
    VarList *varList = makeList();
    
    Signal(SIGINT, sigint_handler); // install signal handler 
    
    // initialize built-in variables
    char CWD[BUFFER_SIZE];
    if (getcwd(CWD, sizeof(CWD)) == NULL) {
        reportError("getcwd()"); // if getcwd() fails,
        strcpy(CWD, "/home"); // assign /home as CWD
    }
    addVariables(varList, "CWD", CWD);
    char* PS = "dhho223>";
    addVariables(varList, "PS", PS);
    char* PATH = "/bin:/usr/bin";
    addVariables(varList, "PATH", PATH);

    while (1) {
        printf("%s ", varList->list[1]->value); // prompt user
        
        char inputLine[BUFFER_SIZE];
        char** parse = calloc(BUFFER_SIZE, sizeof(char*));

        if (fgets(inputLine, BUFFER_SIZE, stdin) == 0) { // handle ^D
            printf("Shell terminated\n");
            exit(0); 
        }
        if (inputLine[strlen(inputLine) - 1] == '\n')
            inputLine[strlen(inputLine) - 1] = '\0';
        size_t numTokens = getTokens(inputLine, parse);

        if (numTokens > 0) {
            cmdHandler(varList, parse, numTokens);
        }
        

    } 
    exit(1); // program should not reach this line
}



