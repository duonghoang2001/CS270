#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include "UDPCookie.h"

#define ERRLEN 128

int main(int argc, char *argv[]) {

  if (argc != 2) // Test for correct number of arguments
    dieWithError("Parameter(s): <Server Port #>");

  char *service = argv[1]; // First arg:  local port/service

  // Construct the server address structure
  struct addrinfo addrCriteria;                   // Criteria for address
  memset(&addrCriteria, 0, sizeof(addrCriteria)); // Zero out structure
  addrCriteria.ai_family = AF_INET;               // We want IPv4 only
  addrCriteria.ai_flags = AI_PASSIVE;             // Accept on any address/port
  addrCriteria.ai_socktype = SOCK_DGRAM;          // Only datagram socket
  addrCriteria.ai_protocol = IPPROTO_UDP;         // UDP socket

  struct addrinfo *servAddr; // List of server addresses
  int rtnVal = getaddrinfo(NULL, service, &addrCriteria, &servAddr);
  if (rtnVal != 0) {
    char error[ERRLEN];
    if (snprintf(error,ERRLEN,"getaddrinfo() failed: %s",
		 gai_strerror(rtnVal)) < 0) // recursive?!
      dieWithSystemError("snprintf() failed");
    dieWithError(error);
  }

  // Create socket for incoming connections
  int sock = socket(servAddr->ai_family, servAddr->ai_socktype,
      servAddr->ai_protocol);
  if (sock < 0)
    dieWithSystemError("socket() failed");

  // Bind to the local address/port
  if (bind(sock, servAddr->ai_addr, servAddr->ai_addrlen) < 0)
    dieWithSystemError("bind() failed");

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  for (;;) { // Run forever
    struct sockaddr_storage clntAddr; // Client address
    // Set Length of client address structure (in-out parameter)
    socklen_t clntAddrLen = sizeof(clntAddr);

    // Block until receive message from a client
    char buffer[MAXMSGLEN]; // I/O buffer
    // Size of received message
    ssize_t numBytesRcvd = recvfrom(sock, buffer, MAXMSGLEN, 0,
        (struct sockaddr *) &clntAddr, &clntAddrLen);
    if (numBytesRcvd < 0)
      dieWithSystemError("recvfrom() failed");

    /* YOUR CODE HERE:  parse & display incoming request message */
    // parse incoming request message
    header_t* msgPtr = (header_t*) buffer;
    msgPtr->magic = ntohs(msgPtr->magic);
    msgPtr->length = ntohs(msgPtr->length);
    int requestVersion = (msgPtr->flags >> 4) & 0xf;
    int requestFlag = msgPtr->flags & 0xf;
    char userID[MAXMSGLEN];
    int userIDLen = msgPtr->length - 12;
    memcpy(userID, &buffer[12], userIDLen);
    userID[userIDLen] = '\0';

    // display incoming request message
    printf("==========================\n");
    printf("Incoming request message:\n");
    printf("magic=%d \n",msgPtr->magic);
    printf("length=%d\n", msgPtr->length);
    printf("xid=%x %x %x %x\n", msgPtr->xactionid >> 24, 
            (msgPtr->xactionid >> 16) & 0xff, (msgPtr->xactionid >> 8) & 0xff, 
            msgPtr->xactionid & 0xff);
    printf("version=%d\n", requestVersion);
    printf("flags=0x%x\n", requestFlag);
    printf("port=%d\n", msgPtr->port);
    printf("result=%d\n",msgPtr->result);
    printf("variable part=%s\n", userID);
    printf("==========================\n");

    /* YOUR CODE HERE:  construct Response message in buffer, display it */
    char msgBuf[MAXMSGLEN];
    header_t* respPtr = (header_t*)msgBuf;
    respPtr->magic = 270;
    respPtr->xactionid = msgPtr->xactionid;
    respPtr->flags = 0x20; // set R flag to 0
    if ((msgPtr->flags >> 3) & 0x1) { // if request's T flag is set
      respPtr->flags = respPtr->flags | 0x8; // set response's T flag
    }
    respPtr->port = msgPtr->port;
    respPtr->result = 15;

    memcpy(userID, &buffer[12], userIDLen);
    char* text = "dhho223"; 
    
    // when detecting error, then take points off accordingly
    if (msgPtr->magic != 270) respPtr->result -= 2; // bad magic #
    if (msgPtr->length != (12 + strlen(userID))) respPtr->result -= 2; // bad length
    if (requestVersion != 2) respPtr->result -= 1; // unsupported version
    if (msgPtr->port || ((msgPtr->flags >> 2) & 0x1)) respPtr->result -= 1; // Port/Type inconsistent
    if ((msgPtr->flags & 0x3) != 0x2) respPtr->result -= 1; // R/E flag inconsistent
    if (msgPtr->length == (12 + strlen(text) + 1)) respPtr->result -= 1; // Terminating null included in length
    if (!((msgPtr->flags >> 1) & 0x1)) respPtr->result -= 1; // Bad R flag
    if (!strlen(userID)) respPtr->result -= 3; // Missing UID
    if (strcmp(userID, text)) respPtr->result -= 3; // Unknown UID
  
    // set E flag if error was detected
    if (respPtr->result < 15) {
      respPtr->flags = respPtr->flags | 0x1;
      text = "error!";
    } else { // if no error was detected
      if ((respPtr->flags >> 3) & 0x1) {// if T flag is set
        // text = userID (assigned above)
      } else { // return cookie if T flag is not set
        // due to previous sanity check, the only difference between Type 0 
        // requests are their xactionids -> create cookie based on xactionid
        char cookie[32];
        char* codes = "abcdefghijklmnopqrstuvwxyzabcdef";
        int index = 0;
        uint digit;
        uint32_t num = msgPtr->xactionid;
        for (int i = 0; i < 32; i++) {
          digit = num & 0x1;
          if (digit) {
            cookie[index] = codes[i];
            index ++;
          } 
          num = num >> 1; 
        }
        text = cookie;
      }
    }

    int msgLen = 12 + strlen(text);
    respPtr->length = msgLen;
    memcpy(msgBuf + 12, text, strlen(text));

    // display response message
    printf("==========================\n");
    printf("Response message:\n");
    printf("magic=%d\n", respPtr->magic);
    printf("length=%d\n", respPtr->length);
    printf("xid=%x %x %x %x\n", respPtr->xactionid >> 24, 
          (respPtr->xactionid >> 16) & 0xff, (respPtr->xactionid >> 8) & 0xff, 
          respPtr->xactionid & 0xff);
    printf("version=%d\n", ((respPtr->flags >> 4) & 0xf));
    printf("flags=0x%x\n", (respPtr->flags & 0xf));
    printf("port=%d\n", respPtr->port);
    printf("result=%d\n", respPtr->result);
    printf("variable part=%s\n", text);
    printf("==========================\n");
    
    // convert to network byte order before sending msg
    respPtr->magic = htons(respPtr->magic);
    respPtr->length = htons(respPtr->length);

    ssize_t numBytesSent = sendto(sock, msgBuf, msgLen, 0,
        (struct sockaddr *) &clntAddr, sizeof(clntAddr));
    if (numBytesSent < 0)
      dieWithSystemError("sendto() failed)");
  }
  // NOT REACHED
}
