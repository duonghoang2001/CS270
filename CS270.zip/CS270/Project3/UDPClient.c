#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include "UDPCookie.h"

typedef void (*sighandler_t)(int);

#define PERIOD 5

void sigalrm_handler() {
  sigset_t mask, prev_mask;
  sigemptyset(&mask);
  sigfillset(&mask); // block all signals
  sigprocmask(SIG_BLOCK, &mask, &prev_mask);
  alarm(PERIOD); // reset alarm
  sigprocmask(SIG_SETMASK, &prev_mask, NULL); // restore original set
} // signal handler for SIGALRM

int main(int argc, char *argv[]) {
  char msgBuf[MAXMSGLEN];
  int msgLen = 0; // quiet the compiler

  if (argc != 3) // Test for correct number of arguments
    dieWithError("Parameter(s): <Server Address/Name> <Server Port/Service>");

  char *server = argv[1];     // First arg: server address/name
  char *servPort = argv[2];

  // Tell the system what kind(s) of address info we want
  struct addrinfo addrCriteria;                   // Criteria for address match
  memset(&addrCriteria, 0, sizeof(addrCriteria)); // Zero out structure
  addrCriteria.ai_family = AF_INET;               // IPv4 only
  // For the following fields, a zero value means "don't care"
  addrCriteria.ai_socktype = SOCK_DGRAM;          // Only datagram sockets
  addrCriteria.ai_protocol = IPPROTO_UDP;         // Only UDP protocol

  // Get address(es)
  struct addrinfo *servAddr;      // List of server addresses
  int rtnVal = getaddrinfo(server, servPort, &addrCriteria, &servAddr);
  if (rtnVal != 0) {
    char error[MAXMSGLEN];
    snprintf(error,MAXMSGLEN,"getaddrinfo() failed: %s",gai_strerror(rtnVal));
    dieWithError(error);
  }
  /* Create a datagram socket */
  int sock = socket(servAddr->ai_family, servAddr->ai_socktype,
		    servAddr->ai_protocol); // Socket descriptor for client
  if (sock < 0)
    dieWithSystemError("socket() failed");

  /* YOUR CODE HERE - construct Request message in msgBuf               */
  /* msgLen must contain the size (in bytes) of the Request msg         */
  
  header_t *msgPtr = (header_t *)msgBuf;
  char* userID = "dhho223"; // linkBlue
  msgLen = 12 + strlen(userID); // sizeof(header_t) = 12
  
  msgPtr->magic = 270;
  msgPtr->length = msgLen;
  msgPtr->xactionid = 0x12729638;
  msgPtr->flags = 0x22;
  msgPtr->result = 0;
  msgPtr->port = 0;
  memcpy(msgBuf+12, userID, strlen(userID));
  msgBuf[msgLen] = '\0';

  // display request message
  printf("==========================\n");
  printf("Request message:\n");
  printf("magic=%d \n",msgPtr->magic);
  printf("length=%d\n", msgPtr->length);
  printf("xid=%x %x %x %x\n", msgPtr->xactionid >> 24, 
            (msgPtr->xactionid >> 16) & 0xff, (msgPtr->xactionid >> 8) & 0xff, 
            msgPtr->xactionid & 0xff);
  printf("version=%d\n", ((msgPtr->flags >> 4) & 0xf));
  printf("flags=0x%x\n", (msgPtr->flags & 0xf));
  printf("port=%d\n", msgPtr->port);
  printf("result=%d\n",msgPtr->result);
  printf("variable part=%s\n", userID);
  printf("==========================\n");

  // convert to network byte order
  msgPtr->magic = htons(msgPtr->magic);
  msgPtr->length = htons(msgPtr->length);
  
  ssize_t numBytes = sendto(sock, msgBuf, msgLen, 0, servAddr->ai_addr,
			    servAddr->ai_addrlen);
  if (numBytes < 0)
    dieWithSystemError("sendto() failed");
  else if (numBytes != msgLen)
    dieWithError("sendto() returned unexpected number of bytes");

  /* YOUR CODE HERE - receive, parse and display response message */
  char recvBuf[MAXMSGLEN];
  int alarmCt = 0;
  int recvFlag = 0;

  struct sigaction action, old_action;
  action.sa_handler = sigalrm_handler;
  sigemptyset(&action.sa_mask);
  action.sa_flags = SA_RESTART;

  if (sigaction(SIGALRM, &action, &old_action) < 0)
    dieWithError("Sigaction error");
  
  while ((alarmCt < 5) && (recvFlag == 0)) { // retransmit request msg
    alarm(PERIOD);
    alarmCt++;
    if (recvfrom(sock, recvBuf, MAXMSGLEN, 0, NULL, NULL) < 0) {
      if (errno == EINTR) {
        numBytes = sendto(sock, msgBuf, msgLen, 0, servAddr->ai_addr, 
                          servAddr->ai_addrlen);
        if (numBytes < 0) {
          dieWithSystemError("sendto() failed");
        } else if (numBytes != msgLen){
          dieWithError("sendto() returned unexpected number of bytes");
        }
      }
    }
    else {
      alarm(0);
      recvFlag = 1;
      printf("\nResponse message received!\n\n");
    }
  }

  // parse response message
  header_t* response = (header_t*) recvBuf;
  response->magic = ntohs(response->magic);
  response->length = ntohs(response->length);
  msgLen = response->length;

  //extract the varied-length part from recvBuf
  char text[MAXMSGLEN];
  int textLen = msgLen - 12;
  memcpy(text, &recvBuf[12], textLen);
  text[textLen] = '\0';
  
  // display response message
  printf("==========================\n");
  printf("Response message:\n");
  printf("magic=%d\n", response->magic);
  printf("length=%d\n", response->length);
  printf("xid=%x %x %x %x\n", response->xactionid >> 24, 
        (response->xactionid >> 16) & 0xff, (response->xactionid >> 8) & 0xff, 
        response->xactionid & 0xff);
  printf("version=%d\n", ((response->flags >> 4) & 0xf));
  printf("flags=0x%x\n", (response->flags & 0xf));
  printf("port=%d\n", response->port);
  printf("result=%d\n", response->result);
  printf("variable part=%s\n", text);
  printf("==========================\n");

  freeaddrinfo(servAddr);

  close(sock);
  exit(0);
}
