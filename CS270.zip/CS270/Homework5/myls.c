#include <unistd.h> // for execve()
#include <stdio.h> // for printf()
#include <sys/types.h> // for WEXITSTATUS
#include <sys/wait.h> // for wait()


int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("Usage: ./myls <argument_for_ls>\n");
    } else {
        char *args[] = {"/bin/ls", argv[1], 0};	/* argv[1] should be /usr/local/bin */
        char *env[] = {0};	/* leave the environment list null */
        int status;

        if (fork() == 0) {
            execve(args[0], args, env);
            perror("execve");	/* if we get here, execve failed */
        } else {
            wait(&status); 
            printf("Child exited with status %d\n", WEXITSTATUS(status));
        }
    }
	return 0;
}