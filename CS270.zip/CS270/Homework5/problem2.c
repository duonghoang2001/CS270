#include <stdio.h>
#include <stdlib.h>

void doit() {
    if (fork() == 0) {
        fork();
        printf("Hi\n");
        return;
    }
    return;
}

int main() {
    doit();
    printf("Hello\n");
    exit(0);
}