#include <stdio.h>
#include <stdlib.h>

int a(int lim) {
  int i = 0, g = 0;
  while(i++ < lim) {
	  g += i;
  }
  return g;
} // a()

int c(int lim) {
  int i = 0, g = 0;
  while(i++ < 20*lim) {
	 g += i;
  }
  return g;
} // c()

int b(int lim) {
  int i = 0, g = 0;
  while(i++ < lim+200000) {
	 g += i;
  }
  c(lim);
  return g;
} // b()

/* ---- main() ---- */
int main(int argc, char** argv)
{
	int iterations;
	if(argc != 2) {
		printf("Usage %s <Number of Iterations>\n", argv[0]);
		exit(-1);
	} else {
		iterations = atoi(argv[1]);
	}
	printf("No of iterations = %d\n", iterations);
	while(iterations--) {
		a(100*iterations);
		b(iterations);
	}
	return(0);
} // main
