#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define LINESIZE 1024
/* the next two are also defined in <limits.h> */
#define INT_MIN 0x80000000
#define INT_MAX 0x7fffffff

int main(int argc, char** argv)
{
  char oneline[LINESIZE];
  int i, val, len;
  char *p;
  int count;
  unsigned bit;

  fprintf(stderr,"Enter a decimal integer between %d and %d: ",INT_MIN,
	  INT_MAX); 
  if (fgets(oneline, 1024, stdin) == NULL) { // NULL indicates end of file
    printf("End of File!\n");
  } else { // got something
    len = strlen(oneline) - 1;  // remove the newline at the end 
    i = 0;
    while ((i<len) && (oneline[i]==' ')) i++; //skip leading spaces
    if (i>=len)  // line contained only spaces
      printf("End of the line!\n");  // reach the end of the line
    else {
      p = &(oneline[i]); // p points to the first non-space character
      sscanf(p, "%d", &val);  // read a decimal integer (positive or negative)
      printf("You entered %d\n",val);
      printf("The value in hexadecimal is %x\n", val);
      fputs("The value in binary is: ",stdout);
      for (bit=0x80000000, count = 0; count < 32; bit>>=1) {
	if (val&bit)
	  putchar('1');
	else
	  putchar('0');
	if ((++count % 4) ==0)
	  putchar(' ');
      }
      putchar('\n');  // end the line
    }
  }
  return 0;
} 
