#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>

typedef void (*sighandler_t)(int);
void dieWithError(char *);

#define LIMIT 20
#define PERIOD 5

/* global variables for communication between handlers and main */
int sigalarm_count = 0;
int sigint_count = 0;

void sigalrm_handler(int sig) {
  sigset_t mask, prev_mask;
  sigemptyset(&mask);
  sigfillset(&mask); // block all signals
  sigprocmask(SIG_BLOCK, &mask, &prev_mask);
  sigalarm_count++;
  alarm(PERIOD); // reset alarm
  sigprocmask(SIG_SETMASK, &prev_mask, NULL); // restore original set
} // signal handler for SIGALRM

void sigint_handler(int sig) {
  sigset_t mask, prev_mask;
  sigemptyset(&mask);
  sigfillset(&mask); // block all signals
  sigprocmask(SIG_BLOCK, &mask, &prev_mask);
  sigint_count++;
  sigprocmask(SIG_SETMASK, &prev_mask, NULL); // restore original set
} // signal handler for SIGINT

sighandler_t Signal(int signum, sighandler_t handler) {
  struct sigaction action, old_action;
  action.sa_handler = handler;
  sigemptyset(&action.sa_mask);
  action.sa_flags = SA_RESTART;

  if (sigaction(signum, &action, &old_action) < 0)
    dieWithError("Signal error");
  return (old_action.sa_handler);
} // signal installing handler

pid_t Fork(void) {
  pid_t pid;

  if ((pid = fork()) < 0)
    dieWithError("Fork error");
  return pid;
} // wrapper for fork()

int main() {
  Signal(SIGALRM, sigalrm_handler);
  Signal(SIGINT, sigint_handler);
  
  if (Fork() == 0) {
    pid_t ppid = getppid();
    printf("Type any character to continue: ");
    getchar();
    for (int i = 0; i < LIMIT; i++) { // send SIGINT to parent process
      int kill_status = kill(ppid, SIGINT);
      if (kill_status != 0) 
        printf("Kill error.\n");
    }
    printf("Child: finished sending SIGINT %d times.\n", LIMIT);
    exit(0);
  } else {
    // install handlers
    
    alarm(PERIOD);

    // block SIGINT and SIGALRM
    sigset_t mask, prev_mask, unblock;
    sigemptyset(&mask);
    sigaddset(&mask, SIGINT);
    sigaddset(&mask, SIGALRM);
    sigemptyset(&unblock); // no signal bit set

    sigprocmask(SIG_BLOCK, &mask, &prev_mask);
    while (sigint_count < LIMIT && sigalarm_count < LIMIT) {
      printf(".\n");
      fflush(stdout);
      sigsuspend(&unblock);
    }
    sigprocmask(SIG_SETMASK, &prev_mask, NULL);
    printf("SIGALRM count: %d\n", sigalarm_count);
    printf("SIGINT count: %d\n", sigint_count);
    exit(0);
  }
}
