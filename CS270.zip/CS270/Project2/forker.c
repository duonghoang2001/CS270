#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <wait.h>

pid_t pid_A, pid_B; // process ID tracker

void dieWithError(char *); // error handler

void greet(char myName) {
  printf("Process %c, PID %d greets you.\n",myName,getpid());
  fflush(stdout);
} // process greeting

void goaway(char myName) {
  printf("Process %c exits normally\n",myName);
  fflush(stdout);
  exit(0);
} // process exiting

void mourn(char child, char parent, int status) {
  printf("Process %c here: Process %c exited with status %d\n",
              parent, child, status);
  fflush(stdout);
} // mourn

pid_t Fork(void) {
  pid_t pid;

  if ((pid = fork()) < 0)
    dieWithError("Fork error");
  return pid;
} // wrapper for fork()

char getName(pid_t pid) {
  if (pid <= 0)
    return 'X'; // error
  else if (pid == pid_A + 1)
    return 'B';
  else 
    return 'D';
}

int main() {
  
  if (Fork() == 0) { /* Process B */
    greet('B');
    pid_B = getpid();
  } else { /* Process A */
    greet('A');
    pid_A = getpid();
  }

  if (Fork() == 0) { /* Process C and Process D */
    if (getppid() == pid_B) { /* Process C - child of Process B */
      greet('C');
      goaway('C');
    } 
    else if (getppid() == pid_A) { /* Process D - child of Process A */
      greet('D');
      goaway('D');
    }
  } else { /* Process A and Process B */
    if (getpid() == pid_B) { // reap child C of Process B
      int status;

      if (waitpid (-1, &status, 0) > 0) {
        if (WIFEXITED(status)) {
          mourn('C', 'B', WEXITSTATUS(status));
          goaway('B');
        } else {
          printf("Process B here: Process C terminated abnormally\n");
          fflush(stdout);
        }
      }
      
    }
    if (getpid() == pid_A) { // reap child B and D of Process A
      int child_status;
      pid_t child_pid;

      while ((child_pid = waitpid(-1, &child_status, 0)) > 0) {
        if (WIFEXITED(child_status)) {
          mourn(getName(child_pid), 'A', child_status);
        } else {
          printf("Process A here: Process %c terminated abnormally\n", 
                  getName(child_pid));
          fflush(stdout);
        }
      }
      goaway('A');
    }
  }
  return 0;
}