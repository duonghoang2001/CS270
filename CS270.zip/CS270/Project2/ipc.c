#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <wait.h>

pid_t pid_A, pid_B, pid_C, pid_D;
static volatile sig_atomic_t sigFlag_1 = 0;
static volatile sig_atomic_t sigFlag_2 = 0;

typedef void (*sighandler_t)(int);
void dieWithError(char *);

void greet(char myName) {
  printf("Process %c, PID %d greets you.\n",myName,getpid());
  fflush(stdout);
}

void goaway(char myName) {
  printf("Process %c exits normally\n",myName);
  fflush(stdout);
  exit(0);
} // process exiting

void mourn(char child, char parent, int status) {
  printf("Process %c here: Process %c exited with status %d\n",
              parent, child, status);
  fflush(stdout);
} // mourn

char getName(pid_t pid) {
  if (pid <= 0)
    return 'X'; // error
  else if (pid == pid_A + 1)
    return 'B';
  else 
    return 'D';
}

pid_t Fork(void) {
  pid_t pid;

  if ((pid = fork()) < 0)
    dieWithError("Fork error");
  return pid;
} // wrapper for fork()

void sigusr1_handler(int signum) {
  sigset_t mask, prev_mask;
  sigemptyset(&mask);
  sigaddset(&mask, SIGUSR1);
  sigprocmask(SIG_BLOCK, &mask, &prev_mask);
  sigFlag_1++;
  sigprocmask(SIG_SETMASK, &prev_mask, NULL);
}

void sigusr2_handler(int signum) {
  sigset_t mask, prev_mask;
  sigemptyset(&mask);
  sigaddset(&mask, SIGUSR2);
  sigprocmask(SIG_BLOCK, &mask, &prev_mask);
  sigFlag_2++;
  sigprocmask(SIG_SETMASK, &prev_mask, NULL);
}

sighandler_t Signal(int signum, sighandler_t handler) {
  struct sigaction action, old_action;
  action.sa_handler = handler;
  sigemptyset(&action.sa_mask);
  action.sa_flags = SA_RESTART;

  if (sigaction(signum, &action, &old_action) < 0)
    dieWithError("Signal error");
  return (old_action.sa_handler);
} // signal installing handler

int main() {
  Signal(SIGUSR1, sigusr1_handler);
  Signal(SIGUSR2, sigusr2_handler);
  sigset_t unblock_USR1, unblock_USR2, maskAll, prev_mask;

  if (sigfillset(&maskAll) < 0) dieWithError("sigfillset error");
  if(sigfillset(&unblock_USR1) < 0) dieWithError("sigfillset error");
  if(sigdelset(&unblock_USR1, SIGUSR1) <0) dieWithError("sigdelset error");
  if(sigfillset(&unblock_USR2) < 0) dieWithError("sigfillset error");
  if(sigdelset(&unblock_USR2, SIGUSR2) <0) dieWithError("sigdelset error");

  if (Fork() == 0) { /* Process B */
    greet('B');
    pid_B = getpid();
  } else { /* Process A */
    greet('A');
    pid_A = getpid();
  }
  
  if (Fork() == 0) { /* Process C and Process D */
    if (getppid() == pid_B) { /* Process C - child of Process B */
      greet('C');
      kill(getppid(), SIGUSR1);
      if(sigprocmask(SIG_BLOCK, &maskAll, &prev_mask) < 0) 
        dieWithError("sigprocmask error");
      while (sigFlag_2 == 0){
        sigsuspend(&unblock_USR2);
      }

      if(sigprocmask(SIG_SETMASK,&prev_mask,NULL) < 0) 
        dieWithError("sigprocmask error");
      if (sigFlag_2 == 1) {
        sigFlag_2 = 0;
        goaway('C');
        kill(getppid(), SIGUSR1);
        exit(0);
      }
    } 
    else if (getppid() == pid_A) { /* Process D - child of Process A */
      if(sigprocmask(SIG_BLOCK, &maskAll, &prev_mask) < 0) 
        dieWithError("sigprocmask error");
      while(sigFlag_1 == 0){
        sigsuspend(&unblock_USR1);
      }

      if(sigprocmask(SIG_SETMASK,&prev_mask,NULL) < 0) 
        dieWithError("sigprocmask error");
      if (sigFlag_1 == 1) {
        sigFlag_1 = 0;
        greet('D');
        kill(getppid(), SIGUSR2);
      }   
      if(sigprocmask(SIG_BLOCK, &maskAll, &prev_mask) < 0) 
        dieWithError("sigprocmask error");
      while(sigFlag_1 == 0){
        sigsuspend(&unblock_USR1);
      }
      if(sigprocmask(SIG_SETMASK,&prev_mask,NULL) < 0) 
        dieWithError("sigprocmask error");
      if (sigFlag_1 == 1) {
        sigFlag_1 = 0;
        goaway('D');
        kill(getppid(), SIGUSR2);
        exit(0);
      }
    }
  }
  else { // in parent process A or B
    if (getpid() == pid_B) {
      // in child process B

      if(sigprocmask(SIG_BLOCK, &maskAll, &prev_mask) < 0) 
        dieWithError("sigprocmask error");
      while(sigFlag_1 == 0){
        sigsuspend(&unblock_USR1);
      }

      if(sigprocmask(SIG_SETMASK,&prev_mask,NULL) < 0) 
        dieWithError("sigprocmask error");
      if (sigFlag_1 == 1) {
        sigFlag_1 = 0;
        kill(getppid(), SIGUSR1);
      }

      if(sigprocmask(SIG_BLOCK, &maskAll, &prev_mask) < 0) 
        dieWithError("sigprocmask error");
      while(sigFlag_2 == 0){
        sigsuspend(&unblock_USR2);
      }

      if(sigprocmask(SIG_SETMASK,&prev_mask,NULL) < 0) 
        dieWithError("sigprocmask error");
      if (sigFlag_2 == 1) {
        sigFlag_2 = 0;
        kill(pid_C, SIGUSR2);
      }

      if(sigprocmask(SIG_BLOCK, &maskAll, &prev_mask) < 0) 
        dieWithError("sigprocmask Error");
      while(sigFlag_1 == 0){
        sigsuspend(&unblock_USR1);
      }

      if (sigprocmask(SIG_SETMASK,&prev_mask,NULL) < 0) 
        dieWithError("sigprocmask Error");
      if (sigFlag_1 == 1) {
        sigFlag_1 = 0;
        kill(getppid(), SIGUSR1);
      }
      if (sigFlag_1 == 1) {
        sigFlag_1 = 0;
      }

      int status;
      if (waitpid (-1, &status, 0) > 0) {
        if (WIFEXITED(status)) {
          mourn('C', 'B', WEXITSTATUS(status));
          goaway('B');
        } else {
          printf("Process B here: Process C terminated abnormally\n");
          fflush(stdout);
        }
      }
    }

    if (getpid() == pid_A) {
      // in procces A 
      if(sigprocmask(SIG_BLOCK, &maskAll, &prev_mask) < 0) 
        dieWithError("sigprocmask Error");
      while(sigFlag_1 == 0){
        sigsuspend(&unblock_USR1);
      }

      if(sigprocmask(SIG_SETMASK,&prev_mask,NULL) < 0) 
        dieWithError("sigprocmask Error");
      if (sigFlag_1 == 1) {
        sigFlag_1 = 0;
        kill(pid_D, SIGUSR1);
      }

      if(sigprocmask(SIG_BLOCK, &maskAll, &prev_mask) < 0) 
        dieWithError("sigprocmask Error");
      while(sigFlag_2 == 0){
        sigsuspend(&unblock_USR2);
      }

      if(sigprocmask(SIG_SETMASK,&prev_mask,NULL) < 0) 
        dieWithError("sigprocmask Error");
      if (sigFlag_2 == 1) {
        sigFlag_2 = 0;
        kill(pid_B, SIGUSR2);
      }

      if(sigprocmask(SIG_BLOCK, &maskAll, &prev_mask) < 0) 
        dieWithError("sigprocmask Error");
      while(sigFlag_1 == 0){
        sigsuspend(&unblock_USR1);
      }

      if(sigprocmask(SIG_SETMASK,&prev_mask,NULL) < 0) 
        dieWithError("sigprocmask Error");
      if (sigFlag_1 == 1) {
        sigFlag_1 = 0;
        kill(pid_D, SIGUSR1);
      }
      if(sigprocmask(SIG_BLOCK, &maskAll, &prev_mask) < 0) 
        dieWithError("sigprocmask Error");
      while(sigFlag_2 == 0){
        sigsuspend(&unblock_USR2);
      }

      if(sigprocmask(SIG_SETMASK,&prev_mask,NULL) < 0) 
        dieWithError("sigprocmask Error");
      if (sigFlag_2 == 1) {
        sigFlag_2 = 0;
      }

      int child_status;
      pid_t child_pid;

      while ((child_pid = waitpid(-1, &child_status, 0)) > 0) {
        if (WIFEXITED(child_status)) {
          mourn(getName(child_pid), 'A', child_status);
        } else {
          printf("Process A here: Process %c terminated abnormally\n", 
                  getName(child_pid));
          fflush(stdout);
        }
      }
      goaway('A');
    }
  }
  return 0;
}
