#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netdb.h>
#include "UDPCookie.h"

int main(int argc, char *argv[]) {
  char msgBuf[MAXMSGLEN];
  int msgLen = 0; // quiet the compiler

  if (argc != 3) // Test for correct number of arguments
    dieWithError("Parameter(s): <Server Address/Name> <Server Port/Service>");

  char *server = argv[1];     // First arg: server address/name
  char *servPort = argv[2];

  // Tell the system what kind(s) of address info we want
  struct addrinfo addrCriteria;                   // Criteria for address match
  memset(&addrCriteria, 0, sizeof(addrCriteria)); // Zero out structure
  addrCriteria.ai_family = AF_INET;               // IPv4 only
  // For the following fields, a zero value means "don't care"
  addrCriteria.ai_socktype = SOCK_DGRAM;          // Only datagram sockets
  addrCriteria.ai_protocol = IPPROTO_UDP;         // Only UDP protocol

  // Get address(es)
  struct addrinfo *servAddr;      // List of server addresses
  int rtnVal = getaddrinfo(server, servPort, &addrCriteria, &servAddr);
  if (rtnVal != 0) {
    char error[MAXMSGLEN];
    snprintf(error,MAXMSGLEN,"getaddrinfo() failed: %s",gai_strerror(rtnVal));
    dieWithError(error);
  }
  /* Create a datagram socket */
  int sock = socket(servAddr->ai_family, servAddr->ai_socktype,
		    servAddr->ai_protocol); // Socket descriptor for client
  if (sock < 0)
    dieWithSystemError("socket() failed");

  /* YOUR CODE HERE - construct Request message in msgBuf               */
  /* msgLen must contain the size (in bytes) of the Request msg         */
  
  struct sockaddr_in sa;
  int sa_len = sizeof(sa);
  if (getsockname(sock, &sa, &sa_len) == -1) {
    perror("getsockname() failed\n");
    return -1;
  }
  printf("Local port is: %d\n", (int) ntohs(sa.sin_port));
  
  ssize_t numBytes = sendto(sock, msgBuf, msgLen, 0, servAddr->ai_addr,
			    servAddr->ai_addrlen);
  if (numBytes < 0)
    dieWithSystemError("sendto() failed");
  else if (numBytes != msgLen)
    dieWithError("sendto() returned unexpected number of bytes");

  if (getsockname(sock, &sa, &sa_len) == -1) {
    perror("getsockname() failed\n");
    return -1;
  }
  printf("Local port is: %d\n", (int) ntohs(sa.sin_port));

  /* YOUR CODE HERE - receive, parse and display response message */
  freeaddrinfo(servAddr);

  close(sock);
  exit(0);
}
