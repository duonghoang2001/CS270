#include "csapp.h"

int main (int argc, char **argv) { // input - descriptor number
    struct stat stat;
    char *type, *readok;

    Fstat(atoi(argv[1]), &stat);
    /* Determine file type */
    if (S_ISREG(stat.st_mode))
        type = "regular";
    else if (S_ISDIR(stat.st_mode))
        type = "directory";
    else
        type = "other";
    /* Check read access */
    if ((stat.st_mode & S_IRUSR))
        readok = "yes";
    else
        readok = "no";

    printf("type: %s, read: %s\n", type, readok);
    exit(0);
}