#include "csapp.h"

int main() {
    /*
    if (Fork() == 0) { // Child 
        Dup2(0, 3);
        Execve("fstatcheck", argv, envp);
    } 
    */
}