#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define BUFFER_MAX 10

void good_echo() {
    char input[BUFFER_MAX];
    size_t length = sizeof(input);
    char *line = malloc(length);

    while(fgets(input, BUFFER_MAX, stdin) != NULL)
    {
        // concatenate input in buffer to stored input
        strcat(line, input); 
        // check whether reach the end of the input
        if (line[strlen(line) - 1] == '\n') { 
            puts(line); // output the input
            break; // end loop
        }
    }
    free(line);
}

int main() {
    printf("Please enter something:\n");
    good_echo();
    return 0;
}