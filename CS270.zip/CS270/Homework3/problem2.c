#include <stdio.h>

struct  avatar_info {
    char name[12];
    short life;
    int strength;
    long loc_x;
    long loc_y;
    long loc_z;
} foo;

int main() {
    struct avatar_info avatars[120];
    struct avatar_info a;   
    printf("Size of avatars: %zu\n", sizeof(avatars));
    printf("Size of foo: %zu\n", sizeof(foo));
    printf("Size of a: %zu\n", sizeof(a));
    printf("Address of foo: %p\n", (void*)&a);
    printf("Address of name: %p\n", &a.name);
    printf("Address of life: %p\n", &a.life);
    printf("Address of strength: %p\n", &a.strength);
    printf("Address of loc_x: %p\n", &a.loc_x);
    printf("Address of loc_y: %p\n", &a.loc_y);
    printf("Address of loc_z: %p\n", &a.loc_z);
}