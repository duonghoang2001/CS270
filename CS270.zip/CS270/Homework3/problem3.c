#include <stdio.h>

/* Recursive popcount*/
long pcount_r(unsigned long x) {
    if (x == 0)
        return 0;
    else {
        printf("x = %zu\n", x);
        printf("address: %p\n", &x);
        return (x & 1) + pcount_r(x >> 1);
    }
}

int main() {
    long result = pcount_r(0x00000012);
    printf("result = %zu\n", result);
    printf("address: %p\n", &result);
    return 0;
}