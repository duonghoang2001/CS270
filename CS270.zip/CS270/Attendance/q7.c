#include <stdio.h>
#include<stdlib.h>

pid_t Fork(void) {
  pid_t retval;
   if ((retval = fork()) < 0)
     exit(1);
   return retval;
}


int main() {
   if (Fork()==0) {
     printf("hello\n");
   }
   Fork();
   printf("hello\n");
   return 0;
}