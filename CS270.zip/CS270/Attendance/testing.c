#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    char text[128];
    char* codes = "abcdefghij";
    int i = 0;
    int digit;
    int num = 12249895;
    while (num > 0) {
        digit = num % 10;
        text[i] = codes[digit];
        i++;
        num /= 10;
    }
    text[i] = '\0';
    printf("%s\n", text);
    return 0;
}