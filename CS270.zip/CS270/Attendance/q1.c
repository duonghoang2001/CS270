#include <stdio.h>
#include <stdlib.h>

int addOK(int x, int y) {
  /* realize addition overflow happens when adding 2 same sign numbers
     yields an opposite sign result */
  int xsign = (x >> 31) & 1;
  int ysign = (y >> 31) & 1;
  int resultsign = ((x + y) >> 31) & 1;
  return !((~(xsign ^ ysign)) & (xsign ^ resultsign));
}

int main() {
    printf("%d\n", addOK(-1, -2147483647));
    printf("%d\n", addOK(1073741824, -1073741824));
    printf("%d\n", addOK(1, 2147483647));
    printf("%d\n", addOK(1073741824, 1073741824));
    return 0;
}