#include "csapp.h"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./p3 <TXTFILE>\n");
    } else {
        int fd;
        struct stat st;
        char *bufp;
        
        fd = Open(argv[1], O_RDWR, 0);
        Fstat(fd, &st);
        
        bufp = mmap(NULL, st.st_size, PROT_WRITE, MAP_PRIVATE, fd, 0);
        *bufp = 'J';
        
        Write(fd, bufp, st.st_size);
        Munmap(bufp, st.st_size);
    }
	exit(0);
}