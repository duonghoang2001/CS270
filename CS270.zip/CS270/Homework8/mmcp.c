#include "csapp.h"

void mmapcopy(int fd, int size, char* file2) {
    /* Ptr to memory mapped area */
    char *bufp;
    bufp = Mmap(NULL, size, PROT_READ, MAP_PRIVATE, fd, 0);

    umask(DEF_UMASK);
    int fd2 = Open(file2, O_WRONLY|O_CREAT|O_TRUNC, DEF_MODE);
    Write(fd2, bufp, size);
    return;
}

/* mmapcopy driver */
int main(int argc, char **argv) {
    struct stat stat;
    int fd;
    /* Check for required cmd line arg */
    if (argc != 3) {
        printf("usage: %s <file1> <file2>\n", argv[0]);
        exit(0);
    }
    /* Copy input file1 to file2 */
    fd = Open(argv[1], O_RDONLY, 0);
    Fstat(fd, &stat);
    mmapcopy(fd, stat.st_size, argv[2]);
    exit(0);
}

