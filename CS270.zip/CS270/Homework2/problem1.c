#include <stdio.h>

long foo (long x, long y) {
    return x*y + 1;
}


int main() {
    printf("%ld\n", foo(3,7));
    printf("%ld\n", foo(1234,5678));
    printf("%ld\n", foo(4294967296L, 2147483648L));
    return 0;
}
