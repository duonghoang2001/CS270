#include "csapp.h"

void *thread(void *vargp);

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr,"Usage: %s <NUMTHREADS>\n", argv[0]);
        exit(1);
    }
    pthread_t tid;
    int n = atoi(argv[1]);
    for (int i = 0; i < n; i++) {
        Pthread_create(&tid, NULL, thread, NULL); // create thread
        Pthread_join(tid, NULL); // reap thread
    }   
    exit(0);
}

void *thread(void *vargp) /* Thread routine */
{
    printf("Hello, world!\n");
    return NULL;
}