#include <stdio.h>  /* printf */
#include <unistd.h> /* fork */
#include <unistd.h> /* perror */
#include <stdlib.h> /* exit */
#include <wait.h>  /* what else */

#define LIMIT 60

void dieWithError(char *msg) {
  perror(msg);
  exit(9);
}

int main(int argc, char *argv[]) {
  int i;
  int val;
  if (argc < 2) {
    printf("Usage: %s <list of integers between 0 and 60>\n",argv[0]);
    exit(1);
 }
  for (i=1; i < argc; i++) {
    if (fork() == 0) {  /* child */
      val = atoi(argv[i]);
      if (val < 0 || val > LIMIT)
	dieWithError("arguments must be at least 0 and at most 60");
      sleep(val);
      printf("%s ",argv[i]);
      exit(0);
    }
  }
  /* reap children */
  for (i=1; i < argc; i++) {
    if ((val = wait(NULL)) < 0)
      dieWithError("wait:");
  }
  /* the kids are all done */
  putchar('\n');
  exit(0);
}
