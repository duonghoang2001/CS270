/* Competing buffered and unbuffered writes to the same output file */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <wait.h>

#define WRITEAMOUNT 240
/* WRITESIZE  must be < 60 */
#define WRITESIZE 20
char *zeros = "00000000000000000000000000000000000000000000000000000000000";

int main() {
  char newline='\n';
  pid_t pid;
  int i, len, retval;

  pid = fork();
  if (pid < 0) {
    perror("forking failure");
    return -1;
  }
  if (pid == 0) { // Child process - will use write and 0s
    len = 0;
    while (len < WRITEAMOUNT) {
      retval = write(STDOUT_FILENO,zeros,WRITESIZE);
      if (retval < WRITESIZE) {
	fprintf(stderr,"Child: short count, requested=%d, retval=%d\n",
		WRITESIZE,retval);
	fflush(stderr);
      }
      len += retval;
      write(STDOUT_FILENO,&newline,1);
    }
  } else { // parent - uses stdio and .s
    for (i=0; i<WRITEAMOUNT; i++) {
      if (putchar('.') == EOF) {
	fprintf(stderr,"Parent: putchar failed\n");
	exit(2);
      }
      if (i%WRITESIZE == (WRITESIZE - 1))
	putchar('\n');
    } // for
    putchar(newline); // XXX nothing to do if it fails
    wait(NULL);  // don't finish before the child
  } // parent
}
